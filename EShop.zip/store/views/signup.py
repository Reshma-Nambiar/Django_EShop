from django.shortcuts import render, redirect
from django.views import View
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        phone = postData.get('mobile')
        email = postData.get('email')
        password = postData.get('password')

        # validate

        error_message = None

        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            phone=phone,
                            email=email,
                            password=password)

        error_message = self.validateCustomer(customer)

        # saving
        if not error_message:
            customer.password = make_password(customer.password)
            customer.register()
            print(first_name, last_name, phone, email, password)
            return redirect('homepage')

        else:
            return render(request, 'signup.html', {'error': error_message})

    def validateCustomer(self, customer):
        error_message = None
        if (not customer.first_name):
            error_message = "First Name required"
        elif len(customer.first_name) < 2:
            error_message = "First Name must be atleast 2 characters"
        elif (not customer.last_name):
            error_message = "Last Name required"
        elif len(customer.last_name) < 2:
            error_message = "Last Name must be atleast 2 characters"
        elif len(customer.phone) != 10:
            error_message = "Invalid Phone Number"
        elif len(customer.email) < 5:
            error_message = "Invalid gmail"
        elif (not customer.password):
            error_message = "Password required"
        elif len(customer.password) < 8:
            error_message = "Password must be minimum 8 characters"
        elif customer.isExists():
            error_message = "User already exists"

        return error_message